Ybera Design System

Load, in this order:
  <link rel="stylesheet" href="ybera-tokens.css">
  <link rel="stylesheet" href="ybera-components.css">
  <link rel="stylesheet" href="ybera-icons.css">
  <script src="ybera-components.js" defer></script>

Icons: <svg class="yb-icon"><use href="ybera-icons.svg#yb-cart"/></svg>
ybera-tokens.json: the same tokens in W3C Design Tokens format.
ybera-bridge.css: only for the current Shopify theme.
